﻿using PersonalBudgetPlanner2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using static PersonalBudgetPlanner2.Program;

namespace PersonalBudgetPlanner2
{
    internal class Program
    {
        public class InvalidTransactionException : Exception
        {
            public InvalidTransactionException(string message) : base(message) { }
        }

        public interface ITransaction : IComparable<ITransaction>
        {
            double Amount { get; set; }
            DateTime Date { get; set; }
            string GetDetails();
            bool Validate();
        }

        public interface IReportGenerator
        {
            void Generate();
            void SaveReport();
        }

        public class ReportGenerator : IReportGenerator
        {
            private readonly BudgetManager _budgetManager;

            public ReportGenerator(BudgetManager budgetManager)
            {
                _budgetManager = budgetManager;
            }

            public void Generate()
            {
                string summary = _budgetManager.GenerateSummary();
                Console.WriteLine("Financial Report:");
                Console.WriteLine(summary);
            }

            public void SaveReport()
            {
                Console.WriteLine("Report has been saved.");
            }
        }

        public class Income : ITransaction
        {
            public double Amount { get; set; }
            public DateTime Date { get; set; }
            public string Type { get; set; }

            public Income(double amount, DateTime date, string type)
            {
                Amount = amount;
                Date = date;
                Type = type;
            }

            public string GetDetails()
            {
                return $"Income: {Amount:C} received on {Date.ToShortDateString()}";
            }

            public bool Validate()
            {
                if (Amount <= 0)
                    throw new InvalidTransactionException("Income amount must be greater than zero.");

                return true;
            }

            public int CompareTo(ITransaction other)
            {
                return Date.CompareTo(other.Date);
            }
        }

        public class Expense : ITransaction
        {
            public double Amount { get; set; }
            public DateTime Date { get; set; }
            public string Category { get; set; }
            public string Description { get; set; }

            public Expense(double amount, DateTime date, string category, string description)
            {
                if (string.IsNullOrEmpty(category))
                    throw new ArgumentNullException(nameof(category), "Category cannot be null or empty.");

                Amount = amount;
                Date = date;
                Category = category;
                Description = description;
            }

            public string GetDetails()
            {
                return $"Expense: {Amount:C} on {Date.ToShortDateString()} for {Category} - {Description}";
            }

            public bool Validate()
            {
                if (Amount <= 0)
                    throw new InvalidTransactionException("Expense amount must be greater than zero.");
                if (string.IsNullOrEmpty(Category))
                    throw new InvalidTransactionException("Category is required.");

                return true;
            }

            public int CompareTo(ITransaction other)
            {
                return Date.CompareTo(other.Date);
            }
        }

        public class Category
        {
            public string Name { get; set; }
            public string Description { get; set; }
            private static List<Category> categories = new List<Category>();

            public void AddCategory()
            {
                categories.Add(this);
                Console.WriteLine($"Category '{Name}' added successfully.");
            }

            public void RemoveCategory()
            {
                if (categories.Remove(this))
                {
                    Console.WriteLine($"Category '{Name}' removed successfully.");
                }
                else
                {
                    Console.WriteLine($"Category '{Name}' not found.");
                }
            }

            public static void ListCategories()
            {
                Console.WriteLine("Current Categories:");
                foreach (var category in categories)
                {
                    Console.WriteLine($"- {category.Name}: {category.Description}");
                }
            }
        }

        public class BudgetManager
        {
            public double MonthlyIncome { get; set; }
            public double BudgetLimit { get; set; } // Budget limit as a percentage
            private List<Expense> Expenses { get; set; }
            private List<Income> Incomes { get; set; }
            private AutoResetEvent saveEvent;
            private Thread saveThread;
            private bool isRunning;

            public event EventHandler<string> BudgetAlert;
            public event EventHandler<string> BudgetLimitExceeded;

            public BudgetManager()
            {
                Expenses = new List<Expense>();
                Incomes = new List<Income>();
                saveEvent = new AutoResetEvent(false);
                isRunning = true;

                saveThread = new Thread(SaveBudgetData);
                saveThread.Start();
            }

            public void SetBudgetLimit(double budgetLimit)
            {
                BudgetLimit = budgetLimit;
            }

            public void AddIncome(Income income)
            {
                if (income.Validate())
                {
                    Incomes.Add(income);
                    CheckBudgetLimit();
                }
            }

            public void AddExpense(Expense expense)
            {
                if (expense.Validate())
                {
                    Expenses.Add(expense);
                    CheckBudgetLimit();
                }
                else
                {
                    Console.WriteLine("Invalid expense data.");
                }
            }

            private void CheckBudgetLimit()
            {
                double totalExpenses = CalculateTotalExpenses();
                double totalIncome = CalculateTotalIncome();
                double percentageUsed = (totalExpenses / MonthlyIncome) * 100;

                if (percentageUsed > 80)
                {
                    BudgetLimitExceeded?.Invoke(this, $"Warning: You have exceeded 80% of your budget! Current usage: {percentageUsed:F2}%");
                }

                if (totalExpenses > MonthlyIncome)
                {
                    BudgetAlert?.Invoke(this, "Budget limit exceeded!");
                }
            }

            private void SaveBudgetData()
            {
                while (isRunning)
                {
                    saveEvent.WaitOne(600000);
                    Console.WriteLine("Saving budget data...");
                }
            }

            public void StopSaving()
            {
                isRunning = false;
                saveEvent.Set();
                saveThread.Join();
            }

            public double CalculateTotalExpenses()
            {
                double total = 0;
                foreach (var expense in Expenses)
                {
                    total += expense.Amount;
                }
                return total;
            }

            public double CalculateTotalIncome()
            {
                double total = 0;
                foreach (var income in Incomes)
                {
                    total += income.Amount;
                }
                return total;
            }

            public string GenerateSummary()
            {
                double totalExpenses = CalculateTotalExpenses();
                double totalIncome = CalculateTotalIncome();
                double remainingBalance = totalIncome - totalExpenses;

                return $"Total Income: {totalIncome:C}\n" +
                       $"Total Expenses: {totalExpenses:C}\n" +
                       $"Remaining Balance: {remainingBalance:C}";
            }
            private void ProvideFinancialAdvice()
            {
                double totalExpenses = CalculateTotalExpenses();
                double totalIncome = CalculateTotalIncome();
                double remainingBalance = totalIncome - totalExpenses;
                double savingsPercentage = (remainingBalance / totalIncome) * 100;

                Console.WriteLine("Financial Advice:");

                if (savingsPercentage < 20)
                {
                    Console.WriteLine("Your savings rate is low. Consider cutting down on non-essential expenses to increase your savings.");
                }

                var expenseCategories = Expenses.GroupBy(e => e.Category)
                                                .Select(g => new
                                                {
                                                    Category = g.Key,
                                                    Total = g.Sum(e => e.Amount)
                                                })
                                                .OrderByDescending(c => c.Total);

                if (expenseCategories.Any())
                {
                    var highestCategory = expenseCategories.First();
                    Console.WriteLine($"You are spending the most on {highestCategory.Category}. Consider reducing spending in this category.");
                }

                if (remainingBalance > 0)
                {
                    Console.WriteLine("Good job! You have a positive balance. Consider investing the remaining balance to grow your wealth.");
                }
                else
                {
                    Console.WriteLine("Warning: You are overspending. Try to adjust your expenses to stay within your income.");
                }
            }
        }


        private static BudgetManager _budgetManager = new BudgetManager();

            static void Main(string[] args)
            {
            if (!AuthenticateUser())
            {
                Console.WriteLine("Invalid username or password.");
                return;
            }

            _budgetManager.BudgetAlert += (sender, message) => Console.WriteLine(message);
            _budgetManager.BudgetLimitExceeded += (sender, message) => Console.WriteLine(message);

            Console.Write("Set your monthly budget amount: ");
            double budgetAmount = double.Parse(Console.ReadLine());
            _budgetManager.MonthlyIncome = budgetAmount;

            Console.Write("Set your budget limit percentage (e.g., 80 for 80%): ");
            double budgetLimitPercentage = double.Parse(Console.ReadLine());
            _budgetManager.SetBudgetLimit(budgetLimitPercentage);

            while (true)
            {
                Console.Clear();
                Console.WriteLine("Personal Budget Planner\n");
                Console.WriteLine("1. Enter Income");
                Console.WriteLine("2. Enter Expense");
                Console.WriteLine("3. View Budget Summary");
                Console.WriteLine("4. Exit");

                string input = Console.ReadLine();

                try
                {
                    ValidateUserInput(input);
                    int choice = int.Parse(input);

                    switch (choice)
                    {
                        case 1:
                            AddIncome();
                            break;
                        case 2:
                            AddExpense();
                            break;
                        case 3:
                            ShowSummary();
                            break;
                        case 4:
                            Console.WriteLine("Exiting...");
                            return;
                        default:
                            Console.WriteLine("Invalid choice. Please try again.");
                            break;
                    }
                }
                catch (InvalidTransactionException ex)
                {
                    Console.WriteLine($"Validation error: {ex.Message}");
                }
                catch (FormatException ex)
                {
                    Console.WriteLine("Invalid input. Please enter a number.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"An unexpected error occurred: {ex.Message}");
                }

                Console.WriteLine("Press any key to continue...");
                Console.ReadKey(true);
            }
        }

        private static void AddIncome()
        {
            Console.Write("Enter type of income: ");
            string type = Console.ReadLine();

            Console.Write("Enter income amount: ");
            double amount = double.Parse(Console.ReadLine());

            Console.Write("Enter income date (YYYY-MM-DD): ");
            DateTime date = DateTime.Parse(Console.ReadLine());

            _budgetManager.AddIncome(new Income(amount, date, type));
            Console.WriteLine("Income added successfully.");
        }

        private static void AddExpense()
        {
            Console.Write("Enter expense amount: ");
            double amount = double.Parse(Console.ReadLine());

            Console.Write("Enter expense date (YYYY-MM-DD): ");
            DateTime date = DateTime.Parse(Console.ReadLine());

            Console.Write("Enter expense category: ");
            string category = Console.ReadLine();

            Console.Write("Enter expense description: ");
            string description = Console.ReadLine();

            _budgetManager.AddExpense(new Expense(amount, date, category, description));
            Console.WriteLine("Expense added successfully.");
        }

        private static void ShowSummary()
        {
            Console.WriteLine(_budgetManager.GenerateSummary());
        }

        private static bool AuthenticateUser()
        {
            int maxAttempts = 3;
            for (int attempt = 1; attempt <= maxAttempts; attempt++)
            {
                Console.Write("Enter username: ");
                string username = Console.ReadLine();

                Console.Write("Enter password: ");
                string password = ReadPassword();

                if (username == "user" && password == "password")
                {
                    return true;
                }
                else
                {
                    Console.WriteLine($"Invalid username or password. Attempt {attempt} of {maxAttempts}.");
                }

                if (attempt == maxAttempts)
                {
                    Console.WriteLine("Maximum attempts reached. Access denied.");
                    return false;
                }
            }

            return false;
        }

        private static string ReadPassword()
        {
            string password = string.Empty;
            ConsoleKeyInfo keyInfo;

            do
            {
                keyInfo = Console.ReadKey(intercept: true);

                if (keyInfo.Key == ConsoleKey.Backspace && password.Length > 0)
                {
                    Console.Write("\b \b");
                    password = password.Substring(0, password.Length - 1);
                }
                else if (keyInfo.Key != ConsoleKey.Enter)
                {
                    Console.Write("*");
                    password += keyInfo.KeyChar;
                }

            } while (keyInfo.Key != ConsoleKey.Enter);

            Console.WriteLine();
            return password;
        }

        private static void ValidateUserInput(string input)
        {
            if (string.IsNullOrEmpty(input))
            {
                throw new InvalidTransactionException("Input cannot be empty.");
            }
        }
    }
}


